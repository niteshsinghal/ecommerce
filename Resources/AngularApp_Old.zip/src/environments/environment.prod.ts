export const environment = {
  production: true,
  sampleApi: {
    baseUrl: "https://reqres.in/api/",
    login: "login" //Post Request
  }
};
